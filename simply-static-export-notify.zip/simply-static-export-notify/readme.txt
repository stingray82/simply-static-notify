=== Simply Static Export & Notify ===
Contributors: reallyusefulplugins
Donate link: https://reallyusefulplugins.com/donate
Tags: simplystatic, automation, export, static, 
Requires at least: 6.5
Tested up to: 6.8.1
Stable tag: 1.0.3
Requires PHP: 8.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Allow you to automatically export when saving post types and get discord notifications, including scheduled Posts

== Description ==

Allow you to automatically export when saving post types and get discord notifications, including scheduled Posts

== Installation ==

1. Upload the `simply-static-export-notify` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Configure the plugin settings it is located in the Simply Static Menu

== Frequently Asked Questions ==

= How do I modify the settings =
After Activating Navigate to the new submenu in the simply static menu `Export/Notify` and modify your settings there
== Changelog ==
= 1.03 24 May 2025 =
Tweak: Automatic Update Test
New: Debug Improvements - Now Select Location, defaults to wpconfig and a txt file, Auto Deletes Log when debugging turned off.
Improvements: Admin Area
New: Sub Menu of Simply Static

= 1.02 24 May 2025 =
Improved: Debug Logging now outside of debug log
New: Automatic Updating 

= 1.01 24 May 2025 =
Improved: Debug Logging

= 1.0 24 May 2025 = 
New: Internal Use Launch

=== Simply Static Export & Notify ===
Contributors: reallyusefulplugins
Donate link: https://reallyusefulplugins.com/donate
Tags: simplystatic, automation, export, static, 
Requires at least: 6.5
Tested up to: 6.8.2
Stable tag: 1.1.10
Requires PHP: 8.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Allow you to automatically export when saving post types and get discord notifications, including scheduled Posts

== Description ==

Allow you to automatically export when saving post types and get discord notifications, including scheduled Posts

== Installation ==

1. Upload the `simply-static-export-notify` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Configure the plugin settings it is located in the Simply Static Menu

== Frequently Asked Questions ==

= How do I modify the settings =
After Activating Navigate to the new submenu in the simply static menu `Export/Notify` and modify your settings there 
== Changelog == 
= 1.1.10 2 Aug 2025 =
New: MainWP Icon Filter

= 1.1.9 27 July 2025 =
New: Prepare Future Support for Preleases
New: Updated UUPD to 1.3.0

= 1.1.8 14 July 2025 =
Update: UUPD 1.2.5

= 1.1.7 06 July 2025 =
New: Rescoped RUP_UUPD
Update: UUPD 1.2.4

= 1.1.6 21 June 2025 =
New: Updates Now served directly from GitHub using UUPD

= 1.1.5 21 June 2025 =
New: Updates Now served directly from GitHub using UUPD

= 1.1.4 21 June 2025 =
New: Updater Script - 1.2.3
New: Direct GitHub Update

= 1.1.3 16 June 2025 =
Tweak: Updater Script - 1.2.3


= 1.1.2 14 June 2025 =
New: Updater Script - This will allow direct from GitHub updates if needed and works with the new deploy script

= 1.1.1 14 June 2025 =
New: Test New Deploy Script

= 1.1 08 June 2025 =
New: Public Release

= 1.0.4 24 May 2025 =
Improve: Updater Class robustness in WP 6.8

= 1.0.3 24 May 2025 =
Tweak: Automatic Update Test
New: Debug Improvements - Now Select Location, defaults to wpconfig and a txt file, Auto Deletes Log when debugging turned off.
Improvements: Admin Area
New: Sub Menu of Simply Static

= 1.0.2 24 May 2025 =
Improved: Debug Logging now outside of debug log
New: Automatic Updating 

= 1.0.1 24 May 2025 =
Improved: Debug Logging

= 1.0 24 May 2025 = 
New: Internal Use Launch
